package com.library.controllers;

import com.library.App;
import com.library.models.Borrow;
import com.library.utils.DatabaseConnection;
import javafx.beans.binding.Bindings;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class BorrowController implements Initializable {

    @FXML private ImageView dashboardIcon;
    @FXML private ImageView booksIcon;
    @FXML private ImageView membersIcon;
    @FXML private ImageView borrowIcon;
    @FXML private ImageView settingsIcon;
    @FXML private ImageView logoutIcon;
    @FXML private TableView<Borrow> borrowTable;
    @FXML private TableColumn<Borrow, Integer> borrowIdColumn;
    @FXML private TableColumn<Borrow, Integer> memberIdColumn;
    @FXML private TableColumn<Borrow, Integer> bookIdColumn;
    @FXML private TableColumn<Borrow, LocalDate> borrowDateColumn;
    @FXML private TableColumn<Borrow, LocalDate> dueDateColumn;
    @FXML private TableColumn<Borrow, String> statusColumn;
    @FXML private TableColumn<Borrow, Void> actionsColumn;

    private ObservableList<Borrow> borrowList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        System.out.println("Initializing BorrowController...");

        // تحميل الأيقونات
        try {
            if (dashboardIcon != null) dashboardIcon.setImage(new Image("/icons/dashboard.png"));
            if (booksIcon != null) booksIcon.setImage(new Image("/icons/books.png"));
            if (membersIcon != null) membersIcon.setImage(new Image("/icons/members.png"));
            if (borrowIcon != null) borrowIcon.setImage(new Image("/icons/borrow.png"));
            if (settingsIcon != null) settingsIcon.setImage(new Image("/icons/settings.png"));
            if (logoutIcon != null) logoutIcon.setImage(new Image("/icons/logout.png"));
        } catch (Exception e) {
            System.err.println("Error loading icons: " + e.getMessage());
        }

        // التحقق من إن الـ TableView والأعمدة مش null
        if (borrowTable == null || borrowIdColumn == null || memberIdColumn == null ||
                bookIdColumn == null || borrowDateColumn == null || dueDateColumn == null ||
                statusColumn == null || actionsColumn == null) {
            System.err.println("TableView or columns are not properly initialized. Check Borrow.fxml.");
            return;
        }

        // ربط الأعمدة بالخصائص
        borrowIdColumn.setCellValueFactory(new PropertyValueFactory<>("borrowId"));
        memberIdColumn.setCellValueFactory(new PropertyValueFactory<>("memberId"));
        bookIdColumn.setCellValueFactory(new PropertyValueFactory<>("bookId"));
        borrowDateColumn.setCellValueFactory(new PropertyValueFactory<>("borrowDate"));
        dueDateColumn.setCellValueFactory(new PropertyValueFactory<>("dueDate"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));

        // إعداد عمود الأكشن (Edit/Delete)
        actionsColumn.setCellFactory(param -> new TableCell<>() {
            private final Button editButton = new Button("Edit");
            private final Button deleteButton = new Button("Delete");

            {
                editButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
                deleteButton.setStyle("-fx-background-color: #f44336; -fx-text-fill: white;");

                editButton.setOnAction(event -> {
                    Borrow borrow = getTableView().getItems().get(getIndex());
                    if (borrow != null) showEditBorrowDialog(borrow);
                });

                deleteButton.setOnAction(event -> {
                    Borrow borrow = getTableView().getItems().get(getIndex());
                    if (borrow != null) deleteBorrow(borrow.getBorrowId());
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : new HBox(5, editButton, deleteButton));
            }
        });

        // ربط الـ TableView بالقائمة
        borrowTable.setItems(borrowList);
        // التأكد من إن الأعمدة تتوسع مع الجدول
        borrowTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        // ربط الحجم ديناميكيًا بعد تحميل الـ Scene
        borrowTable.sceneProperty().addListener((observable, oldScene, newScene) -> {
            if (newScene != null) {
                Stage stage = (Stage) newScene.getWindow();
                if (stage != null) {
                    // ربط عرض الـ TableView بحجم النافذة مع طرح عرض الـ sidebar والـ padding
                    borrowTable.prefWidthProperty().bind(Bindings.subtract(
                            stage.widthProperty(),
                            200 // عرض الـ sidebar (تقريبًا 150) + padding (20+20) + هامش إضافي
                    ));

                    // ربط ارتفاع الـ TableView بحجم النافذة مع طرح المساحات العلوية
                    borrowTable.prefHeightProperty().bind(Bindings.subtract(
                            stage.heightProperty(),
                            100 // مساحة العنوان + الزر + الـ padding
                    ));
                } else {
                    System.err.println("Stage is null. Cannot bind TableView size dynamically.");
                }
            }
        });

        loadBorrowsFromDatabase();
    }

    @FXML
    private void addBorrow() {
        System.out.println("Opening Add Borrow dialog...");
        Dialog<Borrow> dialog = new Dialog<>();
        dialog.setTitle("Add New Borrow");
        dialog.setHeaderText("Enter Borrow Details");

        ButtonType saveButtonType = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        TextField memberIdField = new TextField();
        memberIdField.setPromptText("Member ID");
        TextField bookIdField = new TextField();
        bookIdField.setPromptText("Book ID");
        DatePicker borrowDatePicker = new DatePicker();
        borrowDatePicker.setPromptText("Borrow Date");
        DatePicker dueDatePicker = new DatePicker();
        dueDatePicker.setPromptText("Due Date");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.add(new Label("Member ID:"), 0, 0); grid.add(memberIdField, 1, 0);
        grid.add(new Label("Book ID:"), 0, 1); grid.add(bookIdField, 1, 1);
        grid.add(new Label("Borrow Date:"), 0, 2); grid.add(borrowDatePicker, 1, 2);
        grid.add(new Label("Due Date:"), 0, 3); grid.add(dueDatePicker, 1, 3);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                try {
                    int memberId = Integer.parseInt(memberIdField.getText());
                    int bookId = Integer.parseInt(bookIdField.getText());
                    LocalDate borrowDate = borrowDatePicker.getValue();
                    LocalDate dueDate = dueDatePicker.getValue();

                    if (borrowDate == null || dueDate == null) {
                        throw new IllegalArgumentException("Borrow Date and Due Date are required!");
                    }

                    System.out.println("Creating new Borrow object: Member ID=" + memberId + ", Book ID=" + bookId);
                    return new Borrow(0, memberId, bookId, borrowDate, dueDate, "Borrowed");
                } catch (NumberFormatException e) {
                    System.err.println("Validation error: Invalid number format - " + e.getMessage());
                    showErrorAlert("Invalid Input", "Member ID and Book ID must be numbers!");
                    return null;
                } catch (IllegalArgumentException e) {
                    System.err.println("Validation error: " + e.getMessage());
                    showErrorAlert("Invalid Input", e.getMessage());
                    return null;
                }
            }
            return null;
        });

        dialog.showAndWait().ifPresent(borrow -> {
            saveBorrowToDatabase(borrow);
            borrowList.add(borrow);
            borrowTable.refresh();
        });
    }

    private void showEditBorrowDialog(Borrow borrow) {
        System.out.println("Opening Edit Borrow dialog for borrow ID: " + borrow.getBorrowId());
        Dialog<Borrow> dialog = new Dialog<>();
        dialog.setTitle("Edit Borrow");
        dialog.setHeaderText("Edit Borrow Details");

        ButtonType saveButtonType = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        TextField memberIdField = new TextField(String.valueOf(borrow.getMemberId()));
        TextField bookIdField = new TextField(String.valueOf(borrow.getBookId()));
        DatePicker borrowDatePicker = new DatePicker(borrow.getBorrowDate());
        DatePicker dueDatePicker = new DatePicker(borrow.getDueDate());
        ComboBox<String> statusCombo = new ComboBox<>();
        statusCombo.getItems().addAll("Borrowed", "Returned");
        statusCombo.setValue(borrow.getStatus());

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.add(new Label("Member ID:"), 0, 0); grid.add(memberIdField, 1, 0);
        grid.add(new Label("Book ID:"), 0, 1); grid.add(bookIdField, 1, 1);
        grid.add(new Label("Borrow Date:"), 0, 2); grid.add(borrowDatePicker, 1, 2);
        grid.add(new Label("Due Date:"), 0, 3); grid.add(dueDatePicker, 1, 3);
        grid.add(new Label("Status:"), 0, 4); grid.add(statusCombo, 1, 4);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                try {
                    int memberId = Integer.parseInt(memberIdField.getText());
                    int bookId = Integer.parseInt(bookIdField.getText());
                    LocalDate borrowDate = borrowDatePicker.getValue();
                    LocalDate dueDate = dueDatePicker.getValue();
                    String status = statusCombo.getValue();

                    if (borrowDate == null || dueDate == null || status == null) {
                        throw new IllegalArgumentException("Borrow Date, Due Date, and Status are required!");
                    }

                    System.out.println("Updating Borrow object: Borrow ID=" + borrow.getBorrowId());
                    return new Borrow(borrow.getBorrowId(), memberId, bookId, borrowDate, dueDate, status);
                } catch (NumberFormatException e) {
                    System.err.println("Validation error: Invalid number format - " + e.getMessage());
                    showErrorAlert("Invalid Input", "Member ID and Book ID must be numbers!");
                    return null;
                } catch (IllegalArgumentException e) {
                    System.err.println("Validation error: " + e.getMessage());
                    showErrorAlert("Invalid Input", e.getMessage());
                    return null;
                }
            }
            return null;
        });

        dialog.showAndWait().ifPresent(updatedBorrow -> {
            updateBorrowInDatabase(updatedBorrow);
            int index = borrowList.indexOf(borrow);
            if (index != -1) {
                borrowList.set(index, updatedBorrow);
                borrowTable.refresh();
            }
        });
    }

    private void updateBorrowInDatabase(Borrow borrow) {
        String sql = "UPDATE borrow SET member_id = ?, book_id = ?, borrow_date = ?, due_date = ?, status = ? WHERE borrow_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, borrow.getMemberId());
            pstmt.setInt(2, borrow.getBookId());
            pstmt.setDate(3, Date.valueOf(borrow.getBorrowDate()));
            pstmt.setDate(4, Date.valueOf(borrow.getDueDate()));
            pstmt.setString(5, borrow.getStatus());
            pstmt.setInt(6, borrow.getBorrowId());

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) System.out.println("Borrow updated with ID: " + borrow.getBorrowId());
        } catch (SQLException e) {
            System.err.println("Error updating borrow: " + e.getMessage());
            showErrorAlert("Database Error", "Failed to update borrow: " + e.getMessage());
        }
    }

    private void loadBorrowsFromDatabase() {
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM borrow")) {
            borrowList.clear();
            while (rs.next()) {
                System.out.println("Loading borrow: ID=" + rs.getInt("borrow_id"));
                Borrow borrow = new Borrow(
                        rs.getInt("borrow_id"),
                        rs.getInt("member_id"),
                        rs.getInt("book_id"),
                        rs.getDate("borrow_date") != null ? rs.getDate("borrow_date").toLocalDate() : null,
                        rs.getDate("due_date") != null ? rs.getDate("due_date").toLocalDate() : null,
                        rs.getString("status") != null ? rs.getString("status") : "Borrowed"
                );
                borrowList.add(borrow);
            }
            System.out.println("Total borrows loaded: " + borrowList.size());
            borrowTable.refresh();
        } catch (SQLException e) {
            System.err.println("Error loading borrows: " + e.getMessage());
            showErrorAlert("Database Error", "Failed to load borrows: " + e.getMessage());
        }
    }

    private void saveBorrowToDatabase(Borrow borrow) {
        String sql = "INSERT INTO borrow (member_id, book_id, borrow_date, due_date, status) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setInt(1, borrow.getMemberId());
            pstmt.setInt(2, borrow.getBookId());
            pstmt.setDate(3, Date.valueOf(borrow.getBorrowDate()));
            pstmt.setDate(4, Date.valueOf(borrow.getDueDate()));
            pstmt.setString(5, borrow.getStatus());

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                ResultSet generatedKeys = pstmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    borrow.setBorrowId(generatedKeys.getInt(1));
                    System.out.println("Borrow saved with ID: " + borrow.getBorrowId());
                }
            }
        } catch (SQLException e) {
            System.err.println("Error saving borrow: " + e.getMessage());
            showErrorAlert("Database Error", "Failed to save borrow: " + e.getMessage());
        }
    }

    private void deleteBorrow(int borrowId) {
        String sql = "DELETE FROM borrow WHERE borrow_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, borrowId);
            pstmt.executeUpdate();
            borrowList.removeIf(borrow -> borrow.getBorrowId() == borrowId);
            borrowTable.refresh();
            System.out.println("Borrow deleted with ID: " + borrowId);
        } catch (SQLException e) {
            System.err.println("Error deleting borrow: " + e.getMessage());
            showErrorAlert("Database Error", "Failed to delete borrow: " + e.getMessage());
        }
    }

    @FXML
    private void goToDashboard() {
        try { App.loadDashboardScene((Stage) borrowTable.getScene().getWindow()); } catch (Exception e) { showErrorAlert("Navigation Error", e.getMessage()); }
    }

    @FXML
    private void goToBooks() {
        try { App.loadBooksScene((Stage) borrowTable.getScene().getWindow()); } catch (Exception e) { showErrorAlert("Navigation Error", e.getMessage()); }
    }

    @FXML
    private void goToMembers() {
        try { App.loadMembersScene((Stage) borrowTable.getScene().getWindow()); } catch (Exception e) { showErrorAlert("Navigation Error", e.getMessage()); }
    }

    @FXML
    private void goToBorrow() { /* No need to reload */ }


    @FXML
    private void goToSettings() {
        try { App.loadSettingsScene((Stage) borrowTable.getScene().getWindow()); } catch (Exception e) { showErrorAlert("Navigation Error", e.getMessage()); }
    }

    @FXML
    private void handleLogout() {
        try { App.loadLoginScene((Stage) borrowTable.getScene().getWindow()); } catch (Exception e) { showErrorAlert("Navigation Error", e.getMessage()); }
    }

    private void showErrorAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title); alert.setHeaderText(null); alert.setContentText(message);
        alert.showAndWait();
    }
}