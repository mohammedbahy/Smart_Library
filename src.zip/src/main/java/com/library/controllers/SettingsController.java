package com.library.controllers;

import com.library.App;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class SettingsController implements Initializable {

    @FXML private ImageView dashboardIcon;
    @FXML private ImageView booksIcon;
    @FXML private ImageView membersIcon;
    @FXML private ImageView borrowIcon;
    @FXML private ImageView settingsIcon;
    @FXML private ImageView logoutIcon;
    @FXML private Label settingsLabel;
    @FXML private Label aboutLabel;
    @FXML private Label aboutContent;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Set icons
        try {
            dashboardIcon.setImage(new Image("/icons/dashboard.png"));
            booksIcon.setImage(new Image("/icons/books.png"));
            membersIcon.setImage(new Image("/icons/members.png"));
            borrowIcon.setImage(new Image("/icons/borrow.png"));
            settingsIcon.setImage(new Image("/icons/settings.png"));
            logoutIcon.setImage(new Image("/icons/logout.png"));
        } catch (Exception e) {
            showErrorAlert("Error", "Failed to load icons: " + e.getMessage());
        }

        // Set initial texts
        settingsLabel.setText("Settings");
        aboutLabel.setText("About");
        aboutContent.setText("Library Management System\nVersion: 1.0\nDeveloped by: Mohammed Bahy   Fatma Alzahra Ahmed   Malak Ahmed\nContact: your.email@example.com");
    }

    @FXML
    private void goToDashboard() {
        try {
            App.loadDashboardScene((Stage) settingsLabel.getScene().getWindow());
        } catch (Exception e) {
            showErrorAlert("Failed to load Dashboard", e.getMessage());
        }
    }

    @FXML
    private void goToBooks() {
        try {
            App.loadBooksScene((Stage) settingsLabel.getScene().getWindow());
        } catch (Exception e) {
            showErrorAlert("Failed to load Books", e.getMessage());
        }
    }

    @FXML
    private void goToMembers() {
        try {
            App.loadMembersScene((Stage) settingsLabel.getScene().getWindow());
        } catch (Exception e) {
            showErrorAlert("Failed to load Members", e.getMessage());
        }
    }

    @FXML
    private void goToBorrow() {
        try {
            App.loadBorrowScene((Stage) settingsLabel.getScene().getWindow());
        } catch (Exception e) {
            showErrorAlert("Failed to load Borrow", e.getMessage());
        }
    }


    @FXML
    private void goToSettings() {
        try {
            // No need to reload the same scene
        } catch (Exception e) {
            showErrorAlert("Error in goToSettings", e.getMessage());
        }
    }

    @FXML
    private void handleLogout() {
        try {
            App.loadLoginScene((Stage) settingsLabel.getScene().getWindow());
        } catch (Exception e) {
            showErrorAlert("Failed to load Login", e.getMessage());
        }
    }

    private void showErrorAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}