package com.library.controllers;

import com.library.App;
import com.library.models.Book;
import com.library.utils.DatabaseConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ResourceBundle;

public class BooksController implements Initializable {

    @FXML private ImageView dashboardIcon;
    @FXML private ImageView booksIcon;
    @FXML private ImageView membersIcon;
    @FXML private ImageView borrowIcon;
    @FXML private ImageView settingsIcon;
    @FXML private ImageView logoutIcon;
    @FXML private TableView<Book> booksTable;
    @FXML private TableColumn<Book, Integer> bookIdColumn;
    @FXML private TableColumn<Book, String> titleColumn;
    @FXML private TableColumn<Book, String> authorColumn;
    @FXML private TableColumn<Book, String> publisherColumn;
    @FXML private TableColumn<Book, Date> publishedDateColumn;
    @FXML private TableColumn<Book, String> categoryColumn;
    @FXML private TableColumn<Book, String> statusColumn;
    @FXML private TableColumn<Book, Integer> totalCopiesColumn;
    @FXML private TableColumn<Book, Integer> availableCopiesColumn;
    @FXML private TableColumn<Book, String> isbnColumn;
    @FXML private TableColumn<Book, Timestamp> addedAtColumn;
    @FXML private TableColumn<Book, Void> actionsColumn;

    private ObservableList<Book> booksList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        System.out.println("Initializing BooksController...");
        // Set icons
        try {
            dashboardIcon.setImage(new Image("/icons/dashboard.png"));
            booksIcon.setImage(new Image("/icons/books.png"));
            membersIcon.setImage(new Image("/icons/members.png"));
            borrowIcon.setImage(new Image("/icons/borrow.png"));
            settingsIcon.setImage(new Image("/icons/settings.png"));
            logoutIcon.setImage(new Image("/icons/logout.png"));
        } catch (Exception e) {
            System.err.println("Error loading icons: " + e.getMessage());
            showErrorAlert("Error", "Failed to load icons: " + e.getMessage());
        }

        // Set up table columns
        bookIdColumn.setCellValueFactory(new PropertyValueFactory<>("bookId"));
        titleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        authorColumn.setCellValueFactory(new PropertyValueFactory<>("author"));
        publisherColumn.setCellValueFactory(new PropertyValueFactory<>("publisher"));
        publishedDateColumn.setCellValueFactory(new PropertyValueFactory<>("publishedDate"));
        categoryColumn.setCellValueFactory(new PropertyValueFactory<>("category"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
        totalCopiesColumn.setCellValueFactory(new PropertyValueFactory<>("totalCopies"));
        availableCopiesColumn.setCellValueFactory(new PropertyValueFactory<>("availableCopies"));
        isbnColumn.setCellValueFactory(new PropertyValueFactory<>("isbn"));
        addedAtColumn.setCellValueFactory(new PropertyValueFactory<>("addedAt"));

        // Set up the actions column
        actionsColumn.setCellFactory(param -> new TableCell<>() {
            private final Button editButton = new Button("Edit");
            private final Button deleteButton = new Button("Delete");

            {
                editButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
                deleteButton.setStyle("-fx-background-color: #f44336; -fx-text-fill: white;");

                editButton.setOnAction(event -> {
                    Book book = getTableView().getItems().get(getIndex());
                    showEditBookDialog(book);
                });

                deleteButton.setOnAction(event -> {
                    Book book = getTableView().getItems().get(getIndex());
                    deleteBook(book.getBookId());
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(new HBox(5, editButton, deleteButton));
                }
            }
        });

        // Bind the books list to the table and load data
        booksTable.setItems(booksList);
        System.out.println("Loading books from database...");
        loadBooksFromDatabase();
    }

    @FXML
    private void addBook() {
        System.out.println("Opening Add Book dialog...");
        // Create a dialog for adding a new book
        Dialog<Book> dialog = new Dialog<>();
        dialog.setTitle("Add New Book");
        dialog.setHeaderText("Enter Book Details");

        // Set the button types
        ButtonType saveButtonType = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        // Create the input fields
        TextField titleField = new TextField();
        titleField.setPromptText("Title");
        TextField authorField = new TextField();
        authorField.setPromptText("Author");
        TextField publisherField = new TextField();
        publisherField.setPromptText("Publisher");
        DatePicker publishedDatePicker = new DatePicker();
        publishedDatePicker.setPromptText("Published Date");
        TextField categoryField = new TextField();
        categoryField.setPromptText("Category");
        TextField statusField = new TextField();
        statusField.setPromptText("Status (available/borrowed)");
        TextField totalCopiesField = new TextField();
        totalCopiesField.setPromptText("Total Copies");
        TextField availableCopiesField = new TextField();
        availableCopiesField.setPromptText("Available Copies");
        TextField isbnField = new TextField();
        isbnField.setPromptText("ISBN");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.add(new Label("Title:"), 0, 0);
        grid.add(titleField, 1, 0);
        grid.add(new Label("Author:"), 0, 1);
        grid.add(authorField, 1, 1);
        grid.add(new Label("Publisher:"), 0, 2);
        grid.add(publisherField, 1, 2);
        grid.add(new Label("Published Date:"), 0, 3);
        grid.add(publishedDatePicker, 1, 3);
        grid.add(new Label("Category:"), 0, 4);
        grid.add(categoryField, 1, 4);
        grid.add(new Label("Status:"), 0, 5);
        grid.add(statusField, 1, 5);
        grid.add(new Label("Total Copies:"), 0, 6);
        grid.add(totalCopiesField, 1, 6);
        grid.add(new Label("Available Copies:"), 0, 7);
        grid.add(availableCopiesField, 1, 7);
        grid.add(new Label("ISBN:"), 0, 8);
        grid.add(isbnField, 1, 8);

        dialog.getDialogPane().setContent(grid);

        // Convert the result to a Book object when Save is clicked
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                try {
                    String title = titleField.getText();
                    String author = authorField.getText();
                    String publisher = publisherField.getText();
                    Date publishedDate = publishedDatePicker.getValue() != null ? java.sql.Date.valueOf(publishedDatePicker.getValue()) : null;
                    String category = categoryField.getText();
                    String status = statusField.getText();
                    int totalCopies = totalCopiesField.getText().isEmpty() ? 0 : Integer.parseInt(totalCopiesField.getText());
                    int availableCopies = availableCopiesField.getText().isEmpty() ? 0 : Integer.parseInt(availableCopiesField.getText());
                    String isbn = isbnField.getText();

                    if (title.isEmpty()) {
                        throw new IllegalArgumentException("Title is required!");
                    }
                    if (totalCopies < 0 || availableCopies < 0 || availableCopies > totalCopies) {
                        throw new IllegalArgumentException("Invalid copies values!");
                    }
                    if (!status.isEmpty() && !status.equals("available") && !status.equals("borrowed")) {
                        throw new IllegalArgumentException("Status must be 'available' or 'borrowed'!");
                    }

                    System.out.println("Creating new Book object: " + title);
                    return new Book(0, title, author, publisher, publishedDate, category, status, totalCopies, availableCopies, isbn, Timestamp.valueOf(LocalDateTime.now()));
                } catch (NumberFormatException e) {
                    System.err.println("Invalid input for copies: " + e.getMessage());
                    showErrorAlert("Invalid Input", "Total Copies and Available Copies must be numbers!");
                    return null;
                } catch (IllegalArgumentException e) {
                    System.err.println("Validation error: " + e.getMessage());
                    showErrorAlert("Invalid Input", e.getMessage());
                    return null;
                }
            }
            return null;
        });

        // Show the dialog and handle the result
        dialog.showAndWait().ifPresent(book -> {
            System.out.println("Saving book to database: " + book.getTitle());
            saveBookToDatabase(book);
            booksList.add(book); // Add to table after saving to DB
        });
    }

    private void showEditBookDialog(Book book) {
        System.out.println("Opening Edit Book dialog for book ID: " + book.getBookId());
        // Create a dialog for editing the book
        Dialog<Book> dialog = new Dialog<>();
        dialog.setTitle("Edit Book");
        dialog.setHeaderText("Edit Book Details");

        // Set the button types
        ButtonType saveButtonType = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        // Create the input fields and populate them with the book's current data
        TextField titleField = new TextField(book.getTitle());
        titleField.setPromptText("Title");
        TextField authorField = new TextField(book.getAuthor());
        authorField.setPromptText("Author");
        TextField publisherField = new TextField(book.getPublisher());
        publisherField.setPromptText("Publisher");
        DatePicker publishedDatePicker = new DatePicker();
        if (book.getPublishedDate() != null) {
            publishedDatePicker.setValue(book.getPublishedDate().toLocalDate());
        }
        publishedDatePicker.setPromptText("Published Date");
        TextField categoryField = new TextField(book.getCategory());
        categoryField.setPromptText("Category");
        TextField statusField = new TextField(book.getStatus());
        statusField.setPromptText("Status (available/borrowed)");
        TextField totalCopiesField = new TextField(String.valueOf(book.getTotalCopies()));
        totalCopiesField.setPromptText("Total Copies");
        TextField availableCopiesField = new TextField(String.valueOf(book.getAvailableCopies()));
        availableCopiesField.setPromptText("Available Copies");
        TextField isbnField = new TextField(book.getIsbn());
        isbnField.setPromptText("ISBN");

        // Create a grid to layout the fields
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.add(new Label("Title:"), 0, 0);
        grid.add(titleField, 1, 0);
        grid.add(new Label("Author:"), 0, 1);
        grid.add(authorField, 1, 1);
        grid.add(new Label("Publisher:"), 0, 2);
        grid.add(publisherField, 1, 2);
        grid.add(new Label("Published Date:"), 0, 3);
        grid.add(publishedDatePicker, 1, 3);
        grid.add(new Label("Category:"), 0, 4);
        grid.add(categoryField, 1, 4);
        grid.add(new Label("Status:"), 0, 5);
        grid.add(statusField, 1, 5);
        grid.add(new Label("Total Copies:"), 0, 6);
        grid.add(totalCopiesField, 1, 6);
        grid.add(new Label("Available Copies:"), 0, 7);
        grid.add(availableCopiesField, 1, 7);
        grid.add(new Label("ISBN:"), 0, 8);
        grid.add(isbnField, 1, 8);

        dialog.getDialogPane().setContent(grid);

        // Convert the result to a Book object when Save is clicked
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                try {
                    String title = titleField.getText();
                    String author = authorField.getText();
                    String publisher = publisherField.getText();
                    Date publishedDate = publishedDatePicker.getValue() != null ? java.sql.Date.valueOf(publishedDatePicker.getValue()) : null;
                    String category = categoryField.getText();
                    String status = statusField.getText();
                    int totalCopies = totalCopiesField.getText().isEmpty() ? 0 : Integer.parseInt(totalCopiesField.getText());
                    int availableCopies = availableCopiesField.getText().isEmpty() ? 0 : Integer.parseInt(availableCopiesField.getText());
                    String isbn = isbnField.getText();

                    if (title.isEmpty()) {
                        throw new IllegalArgumentException("Title is required!");
                    }
                    if (totalCopies < 0 || availableCopies < 0 || availableCopies > totalCopies) {
                        throw new IllegalArgumentException("Invalid copies values!");
                    }
                    if (!status.isEmpty() && !status.equals("available") && !status.equals("borrowed")) {
                        throw new IllegalArgumentException("Status must be 'available' or 'borrowed'!");
                    }

                    System.out.println("Updating Book object: " + title);
                    return new Book(book.getBookId(), title, author, publisher, publishedDate, category, status, totalCopies, availableCopies, isbn, book.getAddedAt());
                } catch (NumberFormatException e) {
                    System.err.println("Invalid input for copies: " + e.getMessage());
                    showErrorAlert("Invalid Input", "Total Copies and Available Copies must be numbers!");
                    return null;
                } catch (IllegalArgumentException e) {
                    System.err.println("Validation error: " + e.getMessage());
                    showErrorAlert("Invalid Input", e.getMessage());
                    return null;
                }
            }
            return null;
        });

        // Show the dialog and handle the result
        dialog.showAndWait().ifPresent(updatedBook -> {
            System.out.println("Updating book in database: " + updatedBook.getTitle());
            updateBookInDatabase(updatedBook);
            // Update the book in the TableView
            int index = booksList.indexOf(book);
            if (index != -1) {
                booksList.set(index, updatedBook);
            }
        });
    }

    private void updateBookInDatabase(Book book) {
        String sql = "UPDATE books SET title = ?, author = ?, publisher = ?, publication_date = ?, category = ?, status = ?, total_copies = ?, available_copies = ?, isbn = ? WHERE book_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, book.getTitle());
            pstmt.setString(2, book.getAuthor());
            pstmt.setString(3, book.getPublisher());
            if (book.getPublishedDate() != null) {
                pstmt.setString(4, book.getPublishedDate().toString()); // YYYY-MM-DD
            } else {
                pstmt.setString(4, null);
            }
            pstmt.setString(5, book.getCategory());
            pstmt.setString(6, book.getStatus());
            pstmt.setInt(7, book.getTotalCopies());
            pstmt.setInt(8, book.getAvailableCopies());
            pstmt.setString(9, book.getIsbn());
            pstmt.setInt(10, book.getBookId());

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                System.out.println("Book updated in database with ID: " + book.getBookId());
            } else {
                System.err.println("No rows updated for book ID: " + book.getBookId());
            }
        } catch (SQLException e) {
            System.err.println("Error updating book: " + e.getMessage());
            showErrorAlert("Database Error", "Failed to update book: " + e.getMessage());
        }
    }

    private void loadBooksFromDatabase() {
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM books")) {
            booksList.clear();
            while (rs.next()) {
                // التعامل مع added_at (TEXT)
                String addedAtStr = rs.getString("added_at");
                Timestamp addedAtTimestamp;
                try {
                    if (addedAtStr != null && !addedAtStr.isEmpty()) {
                        // نفترض إن الصيغة YYYY-MM-DD HH:MM:SS أو YYYY-MM-DD
                        if (addedAtStr.length() == 10) { // YYYY-MM-DD
                            addedAtStr += " 00:00:00";
                        }
                        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                        LocalDateTime dateTime = LocalDateTime.parse(addedAtStr, formatter);
                        addedAtTimestamp = Timestamp.valueOf(dateTime);
                    } else {
                        addedAtTimestamp = Timestamp.valueOf(LocalDateTime.now()); // قيمة افتراضية
                    }
                } catch (DateTimeParseException e) {
                    System.err.println("Error parsing added_at for book ID " + rs.getInt("book_id") + ": " + e.getMessage());
                    addedAtTimestamp = Timestamp.valueOf(LocalDateTime.now()); // قيمة افتراضية في حالة الخطأ
                }

                // التعامل مع publication_date (TEXT)
                String publicationDateStr = rs.getString("publication_date");
                Date publishedDate = null;
                try {
                    if (publicationDateStr != null && !publicationDateStr.isEmpty()) {
                        // نفترض الصيغة YYYY-MM-DD
                        publishedDate = java.sql.Date.valueOf(publicationDateStr);
                    }
                } catch (IllegalArgumentException e) {
                    System.err.println("Error parsing publication_date for book ID " + rs.getInt("book_id") + ": " + e.getMessage());
                    // اتركها null إذا فشل التحويل
                }

                // إنشاء الكائن Book
                Book book = new Book(
                        rs.getInt("book_id"),
                        rs.getString("title") != null ? rs.getString("title") : "",
                        rs.getString("author") != null ? rs.getString("author") : "",
                        rs.getString("publisher") != null ? rs.getString("publisher") : "",
                        publishedDate,
                        rs.getString("category") != null ? rs.getString("category") : "",
                        rs.getString("status") != null ? rs.getString("status") : "",
                        rs.getInt("total_copies"),
                        rs.getInt("available_copies"),
                        rs.getString("isbn") != null ? rs.getString("isbn") : "",
                        addedAtTimestamp
                );
                booksList.add(book);
                System.out.println("Loaded book: " + book.getTitle());
            }
        } catch (SQLException e) {
            System.err.println("Error loading books: " + e.getMessage());
            showErrorAlert("Database Error", "Failed to load books: " + e.getMessage());
        }
    }

    private void saveBookToDatabase(Book book) {
        String sql = "INSERT INTO books (title, author, publisher, publication_date, category, status, total_copies, available_copies, isbn, added_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setString(1, book.getTitle());
            pstmt.setString(2, book.getAuthor());
            pstmt.setString(3, book.getPublisher());
            if (book.getPublishedDate() != null) {
                pstmt.setString(4, book.getPublishedDate().toString()); // YYYY-MM-DD
            } else {
                pstmt.setString(4, null);
            }
            pstmt.setString(5, book.getCategory());
            pstmt.setString(6, book.getStatus());
            pstmt.setInt(7, book.getTotalCopies());
            pstmt.setInt(8, book.getAvailableCopies());
            pstmt.setString(9, book.getIsbn());
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String addedAtStr = book.getAddedAt().toLocalDateTime().format(formatter);
            pstmt.setString(10, addedAtStr);

            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                ResultSet generatedKeys = pstmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    book.setBookId(generatedKeys.getInt(1));
                    System.out.println("Book saved with ID: " + book.getBookId());
                }
            }
        } catch (SQLException e) {
            System.err.println("Error saving book: " + e.getMessage());
            showErrorAlert("Database Error", "Failed to save book: " + e.getMessage());
        }
    }

    private void deleteBook(int bookId) {
        String sql = "DELETE FROM books WHERE book_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, bookId);
            pstmt.executeUpdate();
            booksList.removeIf(book -> book.getBookId() == bookId);
            System.out.println("Book deleted with ID: " + bookId);
        } catch (SQLException e) {
            System.err.println("Error deleting book: " + e.getMessage());
            showErrorAlert("Database Error", "Failed to delete book: " + e.getMessage());
        }
    }

    @FXML
    private void goToDashboard() {
        try {
            App.loadDashboardScene((Stage) booksTable.getScene().getWindow());
        } catch (Exception e) {
            showErrorAlert("Failed to load Dashboard", e.getMessage());
        }
    }

    @FXML
    private void goToBooks() {
        try {
            // No need to reload the same scene
        } catch (Exception e) {
            showErrorAlert("Error in goToBooks", e.getMessage());
        }
    }

    @FXML
    private void goToMembers() {
        try {
            App.loadMembersScene((Stage) booksTable.getScene().getWindow());
        } catch (Exception e) {
            showErrorAlert("Failed to load Members", e.getMessage());
        }
    }

    @FXML
    private void goToBorrow() {
        try {
            App.loadBorrowScene((Stage) booksTable.getScene().getWindow());
        } catch (Exception e) {
            showErrorAlert("Failed to load Borrow", e.getMessage());
        }
    }


    @FXML
    private void goToSettings() {
        try {
            App.loadSettingsScene((Stage) booksTable.getScene().getWindow());
        } catch (Exception e) {
            showErrorAlert("Failed to load Settings", e.getMessage());
        }
    }

    @FXML
    private void handleLogout() {
        try {
            App.loadLoginScene((Stage) booksTable.getScene().getWindow());
        } catch (Exception e) {
            showErrorAlert("Failed to load Login", e.getMessage());
        }
    }

    private void showErrorAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}