package com.library.controllers;

import com.library.App;
import com.library.utils.DatabaseConnection;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

public class DashboardController implements Initializable {

    @FXML private ImageView dashboardIcon;
    @FXML private ImageView booksIcon;
    @FXML private ImageView membersIcon;
    @FXML private ImageView borrowIcon;
    @FXML private ImageView settingsIcon;
    @FXML private ImageView logoutIcon;
    @FXML private Label totalBooksLabel;
    @FXML private Label totalMembersLabel;
    @FXML private Label totalBorrowsLabel;
    @FXML private ImageView totalBooksIcon;
    @FXML private ImageView totalMembersIcon;
    @FXML private ImageView totalBorrowsIcon;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Sidebar icons
        dashboardIcon.setImage(new Image("/icons/dashboard.png"));
        booksIcon.setImage(new Image("/icons/books.png"));
        membersIcon.setImage(new Image("/icons/members.png"));
        borrowIcon.setImage(new Image("/icons/borrow.png"));
        settingsIcon.setImage(new Image("/icons/settings.png"));
        logoutIcon.setImage(new Image("/icons/logout.png"));

        // Card icons with fallback
        try {
            totalBooksIcon.setImage(new Image("/icons/total_books_icon.png"));
        } catch (Exception e) {
            totalBooksIcon.setImage(new Image("/icons/books.png"));
        }
        try {
            totalMembersIcon.setImage(new Image("/icons/total_members_icon.png"));
        } catch (Exception e) {
            totalMembersIcon.setImage(new Image("/icons/members.png"));
        }
        try {
            totalBorrowsIcon.setImage(new Image("/icons/total_borrows_icon.png"));
        } catch (Exception e) {
            totalBorrowsIcon.setImage(new Image("/icons/borrow.png"));
        }

        // Fetch data from database and set values
        try {
            fetchAndSetCounts();
        } catch (SQLException e) {
            showErrorAlert("Database Error", "Failed to fetch counts: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void fetchAndSetCounts() throws SQLException {
        try (Connection connection = DatabaseConnection.getConnection();
             Statement statement = connection.createStatement()) {

            System.out.println("Connected to database successfully.");

            // Count total books
            ResultSet booksResult = statement.executeQuery("SELECT COUNT(*) FROM Books");
            int totalBooks = booksResult.next() ? booksResult.getInt(1) : 0;
            System.out.println("Total Books: " + totalBooks);
            totalBooksLabel.setText(String.valueOf(totalBooks));

            // Count total members
            ResultSet membersResult = statement.executeQuery("SELECT COUNT(*) FROM Members");
            int totalMembers = membersResult.next() ? membersResult.getInt(1) : 0;
            System.out.println("Total Members: " + totalMembers);
            totalMembersLabel.setText(String.valueOf(totalMembers));

            // Count total borrows
            ResultSet borrowsResult = statement.executeQuery("SELECT COUNT(*) FROM borrow WHERE status = 'Borrowed'");
            int totalBorrows = borrowsResult.next() ? borrowsResult.getInt(1) : 0;
            System.out.println("Total Borrows: " + totalBorrows);
            totalBorrowsLabel.setText(String.valueOf(totalBorrows));
        } catch (SQLException e) {
            System.out.println("SQL Error: " + e.getMessage());
            throw e;
        }
    }

    @FXML
    private void goToDashboard() {
        try {
            // No need to reload the same scene
        } catch (Exception e) {
            showErrorAlert("Error in goToDashboard", e.getMessage());
        }
    }

    @FXML
    private void goToBooks() {
        try {
            App.loadBooksScene((Stage) totalBooksLabel.getScene().getWindow());
        } catch (IOException e) {
            showErrorAlert("Failed to load Books scene", e.getMessage());
        }
    }

    @FXML
    private void goToMembers() {
        try {
            App.loadMembersScene((Stage) totalBooksLabel.getScene().getWindow());
        } catch (IOException e) {
            showErrorAlert("Failed to load Members scene", e.getMessage());
        }
    }

    @FXML
    private void goToBorrow() {
        try {
            App.loadBorrowScene((Stage) totalBooksLabel.getScene().getWindow());
        } catch (IOException e) {
            showErrorAlert("Failed to load Borrow scene", e.getMessage());
        }
    }

    @FXML
    private void goToSettings() {
        try {
            App.loadSettingsScene((Stage) totalBooksLabel.getScene().getWindow());
        } catch (IOException e) {
            showErrorAlert("Failed to load Settings scene", e.getMessage());
        }
    }

    @FXML
    private void handleLogout() {
        try {
            App.loadLoginScene((Stage) totalBooksLabel.getScene().getWindow());
        } catch (IOException e) {
            showErrorAlert("Failed to load Login scene", e.getMessage());
        }
    }

    private void showErrorAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
