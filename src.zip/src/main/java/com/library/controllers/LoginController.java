package com.library.controllers;

import com.library.App;
import com.library.utils.DatabaseConnection;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class LoginController implements Initializable {

    @FXML private ImageView logoIcon;
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        System.out.println("Initializing LoginController...");
        try {
            // التأكد من تحميل الصورة
            Image logoImage = new Image(getClass().getResourceAsStream("/icons/logo.png"));
            if (logoImage.isError()) {
                throw new Exception("Failed to load logo image");
            }
            logoIcon.setImage(logoImage);
        } catch (Exception e) {
            System.err.println("Error loading logo: " + e.getMessage());
            // نكتفي بتسجيل الخطأ بدون إظهار تنبيه للمستخدم، عشان ما يأثرش على تجربة الدخول
        }
    }

    @FXML
    private void handleLogin() {
        System.out.println("Attempting to log in...");
        String username = usernameField.getText();
        String password = passwordField.getText();

        if (username.isEmpty() || password.isEmpty()) {
            showErrorAlert("Login Failed", "Username and password are required!");
            return;
        }

        if (authenticateUser(username, password)) {
            System.out.println("Login successful for username: " + username);
            try {
                App.loadDashboardScene((Stage) usernameField.getScene().getWindow());
            } catch (Exception e) {
                showErrorAlert("Navigation Error", "Failed to load Dashboard: " + e.getMessage());
            }
        } else {
            showErrorAlert("Login Failed", "Invalid username or password!");
        }
    }

    @FXML
    private void handleForgotPassword() {
        System.out.println("Forgot Password clicked...");
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Forgot Password");
        alert.setHeaderText(null);
        alert.setContentText("Please contact the administrator to reset your password.");
        alert.showAndWait();
    }

    private boolean authenticateUser(String username, String password) {
        String sql = "SELECT * FROM admins WHERE username = ? AND password = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            ResultSet rs = pstmt.executeQuery();

            return rs.next(); // إذا لقى سجل، يبقى الدخول ناجح
        } catch (SQLException e) {
            System.err.println("Error authenticating user: " + e.getMessage());
            showErrorAlert("Database Error", "Failed to authenticate: " + e.getMessage());
            return false;
        }
    }

    @FXML
    private void handleCancel() {
        System.out.println("Cancel button clicked, closing application...");
        Stage stage = (Stage) usernameField.getScene().getWindow();
        stage.close();
    }

    private void showErrorAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}