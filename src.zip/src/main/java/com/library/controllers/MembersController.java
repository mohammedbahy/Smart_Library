package com.library.controllers;

import com.library.App;
import com.library.models.Member;
import com.library.utils.DatabaseConnection;
import javafx.beans.binding.Bindings;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class MembersController implements Initializable {

    @FXML private ImageView dashboardIcon;
    @FXML private ImageView booksIcon;
    @FXML private ImageView membersIcon;
    @FXML private ImageView borrowIcon;
    @FXML private ImageView returnIcon;
    @FXML private ImageView settingsIcon;
    @FXML private ImageView logoutIcon;
    @FXML private TableView<Member> membersTable;
    @FXML private TableColumn<Member, Integer> memberIdColumn;
    @FXML private TableColumn<Member, String> nameColumn;
    @FXML private TableColumn<Member, String> addressColumn;
    @FXML private TableColumn<Member, String> emailColumn;
    @FXML private TableColumn<Member, String> phoneColumn;
    @FXML private TableColumn<Member, Void> actionsColumn;

    private ObservableList<Member> membersList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        System.out.println("Initializing MembersController...");

        // تحميل الأيقونات
        try {
            if (dashboardIcon != null) dashboardIcon.setImage(new Image("/icons/dashboard.png"));
            if (booksIcon != null) booksIcon.setImage(new Image("/icons/books.png"));
            if (membersIcon != null) membersIcon.setImage(new Image("/icons/members.png"));
            if (borrowIcon != null) borrowIcon.setImage(new Image("/icons/borrow.png"));
            if (returnIcon != null) returnIcon.setImage(new Image("/icons/return.png"));
            if (settingsIcon != null) settingsIcon.setImage(new Image("/icons/settings.png"));
            if (logoutIcon != null) logoutIcon.setImage(new Image("/icons/logout.png"));
        } catch (Exception e) {
            System.err.println("Error loading icons: " + e.getMessage());
        }

        // التحقق من إن الـ TableView والأعمدة مش null
        if (membersTable == null || memberIdColumn == null || nameColumn == null ||
                addressColumn == null || emailColumn == null || phoneColumn == null || actionsColumn == null) {
            System.err.println("TableView or columns are not properly initialized. Check Members.fxml.");
            return;
        }

        // ربط الأعمدة بالخصائص
        memberIdColumn.setCellValueFactory(new PropertyValueFactory<>("memberId"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        addressColumn.setCellValueFactory(new PropertyValueFactory<>("address"));
        emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
        phoneColumn.setCellValueFactory(new PropertyValueFactory<>("phone"));

        // إعداد عمود الأكشن (Edit/Delete)
        actionsColumn.setCellFactory(param -> new TableCell<>() {
            private final Button editButton = new Button("Edit");
            private final Button deleteButton = new Button("Delete");

            {
                editButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
                deleteButton.setStyle("-fx-background-color: #f44336; -fx-text-fill: white;");

                editButton.setOnAction(event -> {
                    Member member = getTableView().getItems().get(getIndex());
                    if (member != null) showEditMemberDialog(member);
                });

                deleteButton.setOnAction(event -> {
                    Member member = getTableView().getItems().get(getIndex());
                    if (member != null) deleteMember(member.getMemberId());
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : new HBox(5, editButton, deleteButton));
            }
        });

        // ربط الـ TableView بالقائمة
        membersTable.setItems(membersList);
        // التأكد من إن الأعمدة تتوسع مع الجدول
        membersTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        // ربط الحجم ديناميكيًا بعد تحميل الـ Scene
        membersTable.sceneProperty().addListener((observable, oldScene, newScene) -> {
            if (newScene != null) {
                Stage stage = (Stage) newScene.getWindow();
                if (stage != null) {
                    // ربط عرض الـ TableView بحجم النافذة مع طرح عرض الـ sidebar والـ padding
                    membersTable.prefWidthProperty().bind(Bindings.subtract(
                            stage.widthProperty(),
                            200 // عرض الـ sidebar (تقريبًا 150) + padding (20+20) + هامش إضافي
                    ));

                    // ربط ارتفاع الـ TableView بحجم النافذة مع طرح المساحات العلوية
                    membersTable.prefHeightProperty().bind(Bindings.subtract(
                            stage.heightProperty(),
                            100 // مساحة العنوان + الزر + الـ padding
                    ));
                } else {
                    System.err.println("Stage is null. Cannot bind TableView size dynamically.");
                }
            }
        });

        loadMembersFromDatabase();
    }

    @FXML
    private void addMember() {
        System.out.println("Opening Add Member dialog...");
        Dialog<Member> dialog = new Dialog<>();
        dialog.setTitle("Add New Member");
        dialog.setHeaderText("Enter Member Details");

        ButtonType saveButtonType = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        TextField nameField = new TextField();
        nameField.setPromptText("Name");
        TextField addressField = new TextField();
        addressField.setPromptText("Address");
        TextField emailField = new TextField();
        emailField.setPromptText("Email");
        TextField phoneField = new TextField();
        phoneField.setPromptText("Phone");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.add(new Label("Name:"), 0, 0); grid.add(nameField, 1, 0);
        grid.add(new Label("Address:"), 0, 1); grid.add(addressField, 1, 1);
        grid.add(new Label("Email:"), 0, 2); grid.add(emailField, 1, 2);
        grid.add(new Label("Phone:"), 0, 3); grid.add(phoneField, 1, 3);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                try {
                    String name = nameField.getText();
                    String address = addressField.getText();
                    String email = emailField.getText();
                    String phone = phoneField.getText();

                    if (name == null || name.trim().isEmpty()) {
                        throw new IllegalArgumentException("Name is required!");
                    }

                    System.out.println("Creating new Member object: " + name);
                    return new Member(0, name, address, email, phone);
                } catch (IllegalArgumentException e) {
                    System.err.println("Validation error: " + e.getMessage());
                    showErrorAlert("Invalid Input", e.getMessage());
                    return null;
                }
            }
            return null;
        });

        dialog.showAndWait().ifPresent(member -> {
            saveMemberToDatabase(member);
            membersList.add(member);
            membersTable.refresh();
        });
    }

    private void showEditMemberDialog(Member member) {
        System.out.println("Opening Edit Member dialog for member ID: " + member.getMemberId());
        Dialog<Member> dialog = new Dialog<>();
        dialog.setTitle("Edit Member");
        dialog.setHeaderText("Edit Member Details");

        ButtonType saveButtonType = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        TextField nameField = new TextField(member.getName());
        TextField addressField = new TextField(member.getAddress());
        TextField emailField = new TextField(member.getEmail());
        TextField phoneField = new TextField(member.getPhone());

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.add(new Label("Name:"), 0, 0); grid.add(nameField, 1, 0);
        grid.add(new Label("Address:"), 0, 1); grid.add(addressField, 1, 1);
        grid.add(new Label("Email:"), 0, 2); grid.add(emailField, 1, 2);
        grid.add(new Label("Phone:"), 0, 3); grid.add(phoneField, 1, 3);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                try {
                    String name = nameField.getText();
                    String address = addressField.getText();
                    String email = emailField.getText();
                    String phone = phoneField.getText();

                    if (name == null || name.trim().isEmpty()) {
                        throw new IllegalArgumentException("Name is required!");
                    }

                    System.out.println("Updating Member object: " + name);
                    return new Member(member.getMemberId(), name, address, email, phone);
                } catch (IllegalArgumentException e) {
                    System.err.println("Validation error: " + e.getMessage());
                    showErrorAlert("Invalid Input", e.getMessage());
                    return null;
                }
            }
            return null;
        });

        dialog.showAndWait().ifPresent(updatedMember -> {
            updateMemberInDatabase(updatedMember);
            int index = membersList.indexOf(member);
            if (index != -1) {
                membersList.set(index, updatedMember);
                membersTable.refresh();
            }
        });
    }

    private void updateMemberInDatabase(Member member) {
        String sql = "UPDATE members SET name = ?, address = ?, email = ?, phone = ? WHERE member_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, member.getName());
            pstmt.setString(2, member.getAddress());
            pstmt.setString(3, member.getEmail());
            pstmt.setString(4, member.getPhone());
            pstmt.setInt(5, member.getMemberId());

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) System.out.println("Member updated with ID: " + member.getMemberId());
        } catch (SQLException e) {
            System.err.println("Error updating member: " + e.getMessage());
            showErrorAlert("Database Error", "Failed to update member: " + e.getMessage());
        }
    }

    private void loadMembersFromDatabase() {
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM members")) {
            membersList.clear();
            while (rs.next()) {
                System.out.println("Loading member: ID=" + rs.getInt("member_id") +
                        ", Name=" + rs.getString("name"));
                Member member = new Member(
                        rs.getInt("member_id"),
                        rs.getString("name") != null ? rs.getString("name") : "",
                        rs.getString("address") != null ? rs.getString("address") : "",
                        rs.getString("email") != null ? rs.getString("email") : "",
                        rs.getString("phone") != null ? rs.getString("phone") : ""
                );
                membersList.add(member);
            }
            System.out.println("Total members loaded: " + membersList.size());
            membersTable.refresh();
        } catch (SQLException e) {
            System.err.println("Error loading members: " + e.getMessage());
            showErrorAlert("Database Error", "Failed to load members: " + e.getMessage());
        }
    }

    private void saveMemberToDatabase(Member member) {
        String sql = "INSERT INTO members (name, address, email, phone) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setString(1, member.getName());
            pstmt.setString(2, member.getAddress());
            pstmt.setString(3, member.getEmail());
            pstmt.setString(4, member.getPhone());

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                ResultSet generatedKeys = pstmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    member.setMemberId(generatedKeys.getInt(1));
                    System.out.println("Member saved with ID: " + member.getMemberId());
                }
            }
        } catch (SQLException e) {
            System.err.println("Error saving member: " + e.getMessage());
            showErrorAlert("Database Error", "Failed to save member: " + e.getMessage());
        }
    }

    private void deleteMember(int memberId) {
        String sql = "DELETE FROM members WHERE member_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, memberId);
            pstmt.executeUpdate();
            membersList.removeIf(member -> member.getMemberId() == memberId);
            membersTable.refresh();
            System.out.println("Member deleted with ID: " + memberId);
        } catch (SQLException e) {
            System.err.println("Error deleting member: " + e.getMessage());
            showErrorAlert("Database Error", "Failed to delete member: " + e.getMessage());
        }
    }

    @FXML
    private void goToDashboard() {
        try { App.loadDashboardScene((Stage) membersTable.getScene().getWindow()); } catch (Exception e) { showErrorAlert("Navigation Error", e.getMessage()); }
    }

    @FXML
    private void goToBooks() {
        try { App.loadBooksScene((Stage) membersTable.getScene().getWindow()); } catch (Exception e) { showErrorAlert("Navigation Error", e.getMessage()); }
    }

    @FXML
    private void goToMembers() { /* No need to reload */ }

    @FXML
    private void goToBorrow() {
        try { App.loadBorrowScene((Stage) membersTable.getScene().getWindow()); } catch (Exception e) { showErrorAlert("Navigation Error", e.getMessage()); }
    }

    @FXML
    private void goToSettings() {
        try { App.loadSettingsScene((Stage) membersTable.getScene().getWindow()); } catch (Exception e) { showErrorAlert("Navigation Error", e.getMessage()); }
    }

    @FXML
    private void handleLogout() {
        try { App.loadLoginScene((Stage) membersTable.getScene().getWindow()); } catch (Exception e) { showErrorAlert("Navigation Error", e.getMessage()); }
    }

    private void showErrorAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title); alert.setHeaderText(null); alert.setContentText(message);
        alert.showAndWait();
    }
}