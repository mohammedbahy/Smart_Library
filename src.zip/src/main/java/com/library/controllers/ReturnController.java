package com.library.controllers;

import com.library.App;
import com.library.models.Return;
import com.library.utils.DatabaseConnection;
import javafx.beans.binding.Bindings;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class ReturnController implements Initializable {

    @FXML private ImageView dashboardIcon;
    @FXML private ImageView booksIcon;
    @FXML private ImageView membersIcon;
    @FXML private ImageView borrowIcon;
    @FXML private ImageView returnIcon;
    @FXML private ImageView settingsIcon;
    @FXML private ImageView logoutIcon;
    @FXML private TableView<Return> returnTable;
    @FXML private TableColumn<Return, Integer> returnIdColumn;
    @FXML private TableColumn<Return, Integer> borrowIdColumn;
    @FXML private TableColumn<Return, LocalDate> returnDateColumn;
    @FXML private TableColumn<Return, Double> fineColumn;
    @FXML private TableColumn<Return, String> statusColumn;
    @FXML private TableColumn<Return, Void> actionsColumn;

    private ObservableList<Return> returnList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        System.out.println("Initializing ReturnController...");

        // تحميل الأيقونات
        try {
            if (dashboardIcon != null) dashboardIcon.setImage(new Image("/icons/dashboard.png"));
            if (booksIcon != null) booksIcon.setImage(new Image("/icons/books.png"));
            if (membersIcon != null) membersIcon.setImage(new Image("/icons/members.png"));
            if (borrowIcon != null) borrowIcon.setImage(new Image("/icons/borrow.png"));
            if (returnIcon != null) returnIcon.setImage(new Image("/icons/return.png"));
            if (settingsIcon != null) settingsIcon.setImage(new Image("/icons/settings.png"));
            if (logoutIcon != null) logoutIcon.setImage(new Image("/icons/logout.png"));
        } catch (Exception e) {
            System.err.println("Error loading icons: " + e.getMessage());
        }

        // التحقق من إن الـ TableView والأعمدة مش null
        if (returnTable == null || returnIdColumn == null || borrowIdColumn == null ||
                returnDateColumn == null || fineColumn == null || statusColumn == null || actionsColumn == null) {
            System.err.println("TableView or columns are not properly initialized. Check Return.fxml.");
            return;
        }

        // ربط الأعمدة بالخصائص
        returnIdColumn.setCellValueFactory(new PropertyValueFactory<>("returnId"));
        borrowIdColumn.setCellValueFactory(new PropertyValueFactory<>("borrowId"));
        returnDateColumn.setCellValueFactory(new PropertyValueFactory<>("returnDate"));
        fineColumn.setCellValueFactory(new PropertyValueFactory<>("fine"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));

        // إعداد عمود الأكشن (Edit/Delete)
        actionsColumn.setCellFactory(param -> new TableCell<>() {
            private final Button editButton = new Button("Edit");
            private final Button deleteButton = new Button("Delete");

            {
                editButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
                deleteButton.setStyle("-fx-background-color: #f44336; -fx-text-fill: white;");

                editButton.setOnAction(event -> {
                    Return returnEntry = getTableView().getItems().get(getIndex());
                    if (returnEntry != null) showEditReturnDialog(returnEntry);
                });

                deleteButton.setOnAction(event -> {
                    Return returnEntry = getTableView().getItems().get(getIndex());
                    if (returnEntry != null) deleteReturn(returnEntry.getReturnId());
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : new HBox(5, editButton, deleteButton));
            }
        });

        // ربط الـ TableView بالقائمة
        returnTable.setItems(returnList);
        // التأكد من إن الأعمدة تتوسع مع الجدول
        returnTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        // ربط الحجم ديناميكيًا بعد تحميل الـ Scene
        returnTable.sceneProperty().addListener((observable, oldScene, newScene) -> {
            if (newScene != null) {
                newScene.windowProperty().addListener((obs, oldWindow, newWindow) -> {
                    if (newWindow instanceof Stage) {
                        Stage stage = (Stage) newWindow;
                        // ربط عرض الـ TableView بحجم النافذة مع طرح عرض الـ sidebar والـ padding
                        returnTable.prefWidthProperty().bind(Bindings.subtract(
                                stage.widthProperty(),
                                200 // عرض الـ sidebar (تقريبًا 150) + padding (20+20) + هامش إضافي
                        ));

                        // ربط ارتفاع الـ TableView بحجم النافذة مع طرح المساحات العلوية
                        returnTable.prefHeightProperty().bind(Bindings.subtract(
                                stage.heightProperty(),
                                100 // مساحة العنوان + الزر + الـ padding
                        ));
                    } else {
                        System.err.println("Window is not a Stage. Cannot bind TableView size dynamically.");
                    }
                });
            }
        });

        loadReturnsFromDatabase();
    }

    @FXML
    private void addReturn() {
        System.out.println("Opening Add Return dialog...");
        Dialog<Return> dialog = new Dialog<>();
        dialog.setTitle("Add New Return");
        dialog.setHeaderText("Enter Return Details");

        ButtonType saveButtonType = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        TextField borrowIdField = new TextField();
        borrowIdField.setPromptText("Borrow ID");
        DatePicker returnDatePicker = new DatePicker();
        returnDatePicker.setPromptText("Return Date");
        TextField fineField = new TextField();
        fineField.setPromptText("Fine (optional)");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.add(new Label("Borrow ID:"), 0, 0); grid.add(borrowIdField, 1, 0);
        grid.add(new Label("Return Date:"), 0, 1); grid.add(returnDatePicker, 1, 1);
        grid.add(new Label("Fine:"), 0, 2); grid.add(fineField, 1, 2);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                try {
                    int borrowId = Integer.parseInt(borrowIdField.getText());
                    LocalDate returnDate = returnDatePicker.getValue();
                    String fineText = fineField.getText();
                    double fine = fineText.isEmpty() ? 0.0 : Double.parseDouble(fineText);

                    if (returnDate == null) {
                        throw new IllegalArgumentException("Return Date is required!");
                    }

                    System.out.println("Creating new Return object: Borrow ID=" + borrowId);
                    return new Return(0, borrowId, returnDate, fine, "Returned");
                } catch (NumberFormatException e) {
                    System.err.println("Validation error: Invalid number format - " + e.getMessage());
                    showErrorAlert("Invalid Input", "Borrow ID and Fine must be numbers!");
                    return null;
                } catch (IllegalArgumentException e) {
                    System.err.println("Validation error: " + e.getMessage());
                    showErrorAlert("Invalid Input", e.getMessage());
                    return null;
                }
            }
            return null;
        });

        dialog.showAndWait().ifPresent(returnEntry -> {
            saveReturnToDatabase(returnEntry);
            returnList.add(returnEntry);
            returnTable.refresh();
        });
    }

    private void showEditReturnDialog(Return returnEntry) {
        System.out.println("Opening Edit Return dialog for return ID: " + returnEntry.getReturnId());
        Dialog<Return> dialog = new Dialog<>();
        dialog.setTitle("Edit Return");
        dialog.setHeaderText("Edit Return Details");

        ButtonType saveButtonType = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        TextField borrowIdField = new TextField(String.valueOf(returnEntry.getBorrowId()));
        DatePicker returnDatePicker = new DatePicker(returnEntry.getReturnDate());
        TextField fineField = new TextField(String.valueOf(returnEntry.getFine()));
        ComboBox<String> statusCombo = new ComboBox<>();
        statusCombo.getItems().addAll("Returned", "Late");
        statusCombo.setValue(returnEntry.getStatus());

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.add(new Label("Borrow ID:"), 0, 0); grid.add(borrowIdField, 1, 0);
        grid.add(new Label("Return Date:"), 0, 1); grid.add(returnDatePicker, 1, 1);
        grid.add(new Label("Fine:"), 0, 2); grid.add(fineField, 1, 2);
        grid.add(new Label("Status:"), 0, 3); grid.add(statusCombo, 1, 3);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                try {
                    int borrowId = Integer.parseInt(borrowIdField.getText());
                    LocalDate returnDate = returnDatePicker.getValue();
                    double fine = Double.parseDouble(fineField.getText());
                    String status = statusCombo.getValue();

                    if (returnDate == null || status == null) {
                        throw new IllegalArgumentException("Return Date and Status are required!");
                    }

                    System.out.println("Updating Return object: Return ID=" + returnEntry.getReturnId());
                    return new Return(returnEntry.getReturnId(), borrowId, returnDate, fine, status);
                } catch (NumberFormatException e) {
                    System.err.println("Validation error: Invalid number format - " + e.getMessage());
                    showErrorAlert("Invalid Input", "Borrow ID and Fine must be numbers!");
                    return null;
                } catch (IllegalArgumentException e) {
                    System.err.println("Validation error: " + e.getMessage());
                    showErrorAlert("Invalid Input", e.getMessage());
                    return null;
                }
            }
            return null;
        });

        dialog.showAndWait().ifPresent(updatedReturn -> {
            updateReturnInDatabase(updatedReturn);
            int index = returnList.indexOf(returnEntry);
            if (index != -1) {
                returnList.set(index, updatedReturn);
                returnTable.refresh();
            }
        });
    }

    private void updateReturnInDatabase(Return returnEntry) {
        String sql = "UPDATE return SET borrow_id = ?, return_date = ?, fine = ?, status = ? WHERE return_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, returnEntry.getBorrowId());
            pstmt.setDate(2, Date.valueOf(returnEntry.getReturnDate()));
            pstmt.setDouble(3, returnEntry.getFine());
            pstmt.setString(4, returnEntry.getStatus());
            pstmt.setInt(5, returnEntry.getReturnId());

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) System.out.println("Return updated with ID: " + returnEntry.getReturnId());
        } catch (SQLException e) {
            System.err.println("Error updating return: " + e.getMessage());
            showErrorAlert("Database Error", "Failed to update return: " + e.getMessage());
        }
    }

    private void loadReturnsFromDatabase() {
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM return")) {
            returnList.clear();
            while (rs.next()) {
                System.out.println("Loading return: ID=" + rs.getInt("return_id"));
                Return returnEntry = new Return(
                        rs.getInt("return_id"),
                        rs.getInt("borrow_id"),
                        rs.getDate("return_date") != null ? rs.getDate("return_date").toLocalDate() : null,
                        rs.getDouble("fine"),
                        rs.getString("status") != null ? rs.getString("status") : "Returned"
                );
                returnList.add(returnEntry);
            }
            System.out.println("Total returns loaded: " + returnList.size());
            returnTable.refresh();
        } catch (SQLException e) {
            System.err.println("Error loading returns: " + e.getMessage());
            showErrorAlert("Database Error", "Failed to load returns: " + e.getMessage());
        }
    }

    private void saveReturnToDatabase(Return returnEntry) {
        String sql = "INSERT INTO return (borrow_id, return_date, fine, status) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setInt(1, returnEntry.getBorrowId());
            pstmt.setDate(2, Date.valueOf(returnEntry.getReturnDate()));
            pstmt.setDouble(3, returnEntry.getFine());
            pstmt.setString(4, returnEntry.getStatus());

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                ResultSet generatedKeys = pstmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    returnEntry.setReturnId(generatedKeys.getInt(1));
                    System.out.println("Return saved with ID: " + returnEntry.getReturnId());
                }
            }
        } catch (SQLException e) {
            System.err.println("Error saving return: " + e.getMessage());
            showErrorAlert("Database Error", "Failed to save return: " + e.getMessage());
        }
    }

    private void deleteReturn(int returnId) {
        String sql = "DELETE FROM return WHERE return_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, returnId);
            pstmt.executeUpdate();
            returnList.removeIf(returnEntry -> returnEntry.getReturnId() == returnId);
            returnTable.refresh();
            System.out.println("Return deleted with ID: " + returnId);
        } catch (SQLException e) {
            System.err.println("Error deleting return: " + e.getMessage());
            showErrorAlert("Database Error", "Failed to delete return: " + e.getMessage());
        }
    }

    @FXML
    private void goToDashboard() {
        try { App.loadDashboardScene((Stage) returnTable.getScene().getWindow()); } catch (Exception e) { showErrorAlert("Navigation Error", e.getMessage()); }
    }

    @FXML
    private void goToBooks() {
        try { App.loadBooksScene((Stage) returnTable.getScene().getWindow()); } catch (Exception e) { showErrorAlert("Navigation Error", e.getMessage()); }
    }

    @FXML
    private void goToMembers() {
        try { App.loadMembersScene((Stage) returnTable.getScene().getWindow()); } catch (Exception e) { showErrorAlert("Navigation Error", e.getMessage()); }
    }

    @FXML
    private void goToBorrow() {
        try { App.loadBorrowScene((Stage) returnTable.getScene().getWindow()); } catch (Exception e) { showErrorAlert("Navigation Error", e.getMessage()); }
    }

    @FXML
    private void goToReturn() { /* No need to reload */ }

    @FXML
    private void goToSettings() {
        try { App.loadSettingsScene((Stage) returnTable.getScene().getWindow()); } catch (Exception e) { showErrorAlert("Navigation Error", e.getMessage()); }
    }

    @FXML
    private void handleLogout() {
        try { App.loadLoginScene((Stage) returnTable.getScene().getWindow()); } catch (Exception e) { showErrorAlert("Navigation Error", e.getMessage()); }
    }

    private void showErrorAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title); alert.setHeaderText(null); alert.setContentText(message);
        alert.showAndWait();
    }
}