package com.library.models;

import java.time.LocalDate;

public class Return {
    private int returnId;
    private int borrowId;
    private LocalDate returnDate;
    private double fine;
    private String status;

    public Return(int returnId, int borrowId, LocalDate returnDate, double fine, String status) {
        this.returnId = returnId;
        this.borrowId = borrowId;
        this.returnDate = returnDate;
        this.fine = fine;
        this.status = status;
    }

    // Getters and Setters
    public int getReturnId() {
        return returnId;
    }

    public void setReturnId(int returnId) {
        this.returnId = returnId;
    }

    public int getBorrowId() {
        return borrowId;
    }

    public void setBorrowId(int borrowId) {
        this.borrowId = borrowId;
    }

    public LocalDate getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(LocalDate returnDate) {
        this.returnDate = returnDate;
    }

    public double getFine() {
        return fine;
    }

    public void setFine(double fine) {
        this.fine = fine;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Return{" +
                "returnId=" + returnId +
                ", borrowId=" + borrowId +
                ", returnDate=" + returnDate +
                ", fine=" + fine +
                ", status='" + status + '\'' +
                '}';
    }
}