package com.library;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.logging.Logger;
import java.util.logging.Level;

public class App extends Application {
    private static Stage primaryStage;
    private static final Logger LOGGER = Logger.getLogger(App.class.getName());
    private static final double WIDTH = 800;
    private static final double HEIGHT = 600;

    @Override
    public void start(Stage stage) {
        primaryStage = stage;
        try {
            loadLoginScene(stage);
            stage.setWidth(WIDTH);
            stage.setHeight(HEIGHT);
            stage.setMinWidth(WIDTH);
            stage.setMinHeight(HEIGHT);
            stage.show();
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Failed to load Login scene. Check if Login.fxml exists in src/main/resources/com/library/views/", e);
        }
    }

    public static void loadLoginScene(Stage stage) throws IOException {
        URL resource = App.class.getResource("/com/library/views/Login.fxml");
        if (resource == null) {
            throw new IOException("Resource not found: /com/library/views/Login.fxml");
        }
        Parent root = FXMLLoader.load(Objects.requireNonNull(resource));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("SMART Library Management System");
    }

    public static void loadMembersScene(Stage stage) throws IOException {
        URL resource = App.class.getResource("/com/library/views/Members.fxml");
        if (resource == null) {
            throw new IOException("Resource not found: /com/library/views/Members.fxml");
        }
        Parent root = FXMLLoader.load(Objects.requireNonNull(resource));
        Scene scene = new Scene(root);
        stage.setScene(scene);
    }

    public static void loadDashboardScene(Stage stage) throws IOException {
        URL resource = App.class.getResource("/com/library/views/Dashboard.fxml");
        if (resource == null) {
            throw new IOException("Resource not found: /com/library/views/Dashboard.fxml");
        }
        Parent root = FXMLLoader.load(Objects.requireNonNull(resource));
        Scene scene = new Scene(root);
        stage.setScene(scene);
    }

    public static void loadBooksScene(Stage stage) throws IOException {
        URL resource = App.class.getResource("/com/library/views/Books.fxml");
        if (resource == null) {
            throw new IOException("Resource not found: /com/library/views/Books.fxml");
        }
        Parent root = FXMLLoader.load(Objects.requireNonNull(resource));
        Scene scene = new Scene(root);
        stage.setScene(scene);
    }

    public static void loadBorrowScene(Stage stage) throws IOException {
        URL resource = App.class.getResource("/com/library/views/Borrow.fxml");
        if (resource == null) {
            throw new IOException("Resource not found: /com/library/views/Borrow.fxml");
        }
        Parent root = FXMLLoader.load(Objects.requireNonNull(resource));
        Scene scene = new Scene(root);
        stage.setScene(scene);
    }

    public static void loadReturnScene(Stage stage) throws IOException {
        URL resource = App.class.getResource("/com/library/views/Return.fxml");
        if (resource == null) {
            throw new IOException("Resource not found: /com/library/views/Return.fxml");
        }
        Parent root = FXMLLoader.load(Objects.requireNonNull(resource));
        Scene scene = new Scene(root);
        stage.setScene(scene);
    }

    public static void loadSettingsScene(Stage stage) throws IOException {
        URL resource = App.class.getResource("/com/library/views/Settings.fxml");
        if (resource == null) {
            throw new IOException("Resource not found: /com/library/views/Settings.fxml");
        }
        Parent root = FXMLLoader.load(Objects.requireNonNull(resource));
        Scene scene = new Scene(root);
        stage.setScene(scene);
    }

    public static Stage getPrimaryStage() {
        return primaryStage;
    }

    public static void main(String[] args) {
        launch();
    }
}